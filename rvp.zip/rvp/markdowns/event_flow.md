#### Overview

![](./diagrams/NeMoFlowDiagram.pdf)

Event Flow Diagram

NeMo features two primary message types:


