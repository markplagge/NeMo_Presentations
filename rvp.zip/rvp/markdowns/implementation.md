Implemented using ROSS system

Allows for parallelism and 