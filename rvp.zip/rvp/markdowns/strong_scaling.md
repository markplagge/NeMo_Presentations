![](./result_img/strong_scale.png)<!-- .element: class="fill" width="40%" -->

- Strong scaling shows initially excellent results
- The simulation begins to loose parallelism
- Larger simulation runs should improve strong scaling 