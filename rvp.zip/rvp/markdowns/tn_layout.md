### TrueNorth Layout

A Neurosynaptic Core is 256 neurons, interconnected

<img src="./tn_slides/neurosynaptic_core.png" width="50%">

