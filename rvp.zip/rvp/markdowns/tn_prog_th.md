###Programming TrueNorth Concepts

- TrueNorth is inspired by biology but does not seek to mimic it exactly
- TrueNorth chip is a network of neurosynaptic cores
- A TrueNorth “program” is a complete specification of that network, including inputs and outputs
- That program is specified as a “corelet”
- Tools like Caffe can be used to learn TrueNorth-compatible corelets from data
