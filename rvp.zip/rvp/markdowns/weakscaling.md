![](./result_img/weak_scaling_en_chart.png)<!-- .element: class="fill" width="40%" -->

- NeMo shows excellent weak scaling performance
